#!/bin/bash

# auto_daemonizer.sh
# Converts any command into a background daemon with colorful status

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
DAEMON_NAME="custom_daemon"
PID_FILE="/tmp/$DAEMON_NAME.pid"
LOG_FILE="/tmp/$DAEMON_NAME.log"

# Function to display status
display_status() {
    clear
    echo -e "${BLUE}=== Auto Daemonizer: $DAEMON_NAME ===${NC}"
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            cpu=$(ps -p "$pid" -o %cpu | tail -n 1 | awk '{print $1}')
            mem=$(ps -p "$pid" -o %mem | tail -n 1 | awk '{print $1}')
            echo -e "${GREEN}Status: Running${NC}"
            echo -e "${YELLOW}PID: $pid${NC}"
            echo -e "${YELLOW}CPU: $cpu%${NC}"
            echo -e "${YELLOW}Mem: $mem%${NC}"
            echo -e "${YELLOW}Log: $LOG_FILE${NC}"
        else
            echo -e "${RED}Status: Stopped (stale PID file)${NC}"
        fi
    else
        echo -e "${RED}Status: Stopped${NC}"
    fi
}

# Function to start daemon
start_daemon() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo -e "${RED}Daemon already running!${NC}"
        exit 1
    fi
    bash -c "$1" >> "$LOG_FILE" 2>&1 &
    pid=$!
    echo "$pid" > "$PID_FILE"
    echo -e "${GREEN}Daemon started with PID $pid${NC}"
}

# Function to stop daemon
stop_daemon() {
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid"
            rm -f "$PID_FILE"
            echo -e "${GREEN}Daemon stopped${NC}"
        else
            echo -e "${RED}Daemon not running${NC}"
            rm -f "$PID_FILE"
        fi
    else
        echo -e "${RED}Daemon not running${NC}"
    fi
}

# Main function
main() {
    if [ $# -lt 2 ]; then
        echo -e "${RED}Usage: $0 {start|stop|restart|status} <command>${NC}"
        echo -e "${YELLOW}Example: $0 start 'sleep 100'${NC}"
        exit 1
    fi

    action=$1
    shift
    command="$@"

    case "$action" in
        start)
            start_daemon "$command"
            ;;
        stop)
            stop_daemon
            ;;
        restart)
            stop_daemon
            sleep 1
            start_daemon "$command"
            ;;
        status)
            display_status
            ;;
        *)
            echo -e "${RED}Invalid action! Use start, stop, restart, or status${NC}"
            exit 1
            ;;
    esac
}

# Run main
main "$@"