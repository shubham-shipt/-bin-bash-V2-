#!/bin/bash

# tcp_port_sniffer_raw.sh
# Sniffs TCP connections using /dev/tcp with colorful output

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Log file
LOG_FILE="/tmp/tcp_sniffer.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, sniffing band! Cleaning up...${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== TCP Port Sniffer ===${NC}"
    echo -e "${GREEN}Listening on port $PORT${NC}\n"
}

# Display connections
display_connections() {
    display_header
    printf "${BLUE}%-20s %-10s %-20s${NC}\n" "Source IP" "Port" "Timestamp"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    tail -n 5 "$LOG_FILE" | while IFS='|' read -r ip port time; do
        printf "${YELLOW}%-20s %-10s %-20s${NC}\n" "$ip" "$port" "$time"
    done
}

# Sniff TCP
sniff_tcp() {
    local port=$1
    while true; do
        {
            read -r line < "/dev/tcp/0.0.0.0/$port"
            src_ip=$(echo "$line" | awk '{print $1}')
            src_port=$(echo "$line" | awk '{print $2}')
            timestamp=$(date '+%Y-%m-%d %H:%M:%S')
            echo "$src_ip|$src_port|$timestamp" >> "$LOG_FILE"
        } 2>/dev/null
        display_connections
        sleep 0.1
    done
}

# Main
main() {
    if [ $# -ne 1 ]; then
        echo -e "${RED}Bhai, port number de! Usage: $0 <port>${NC}"
        echo -e "${YELLOW}Example: $0 8080${NC}"
        exit 1
    fi

    PORT=$1
    touch "$LOG_FILE"

    # Check if port is numeric
    if ! [[ "$PORT" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Port number numeric hona chahiye!${NC}"
        exit 1
    fi

    sniff_tcp "$PORT"
}

main "$@"