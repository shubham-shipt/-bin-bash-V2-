#!/bin/bash
#!/bin/bash

# wifi_auto_scanner_logger.sh
# Scans WiFi networks, logs RSSI with colorful table

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/wifi_scanner.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, WiFi scanner band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== WiFi Scanner ===${NC}"
    echo -e "${GREEN}Scanning nearby networks${NC}\n"
}

# Display networks
display_networks() {
    display_header
    printf "${BLUE}%-20s %-10s %-10s${NC}\n" "SSID" "RSSI" "Channel"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    tail -n 5 /tmp/wifi_scan.txt | while IFS='|' read -r ssid rssi channel; do
        printf "${YELLOW}%-20s %-10s %-10s${NC}\n" "$ssid" "$rssi" "$channel"
    done
}

# Scan WiFi
scan_wifi() {
    touch "$LOG_FILE" /tmp/wifi_scan.txt
    nmcli -f SSID,SIGNAL,CHAN dev wifi | tail -n +2 | while read -r line; do
        ssid=$(echo "$line" | awk '{print $1}')
        rssi=$(echo "$line" | awk '{print $2}')
        channel=$(echo "$line" | awk '{print $3}')
        [ -z "$ssid" ] && continue
        timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        echo "$ssid|$rssi|$channel" >> /tmp/wifi_scan.txt
        echo "$timestamp $ssid RSSI:$rssi Channel:$channel" >> "$LOG_FILE"
    done
    sort -u /tmp/wifi_scan.txt -o /tmp/wifi_scan.txt
    display_networks
}

# Main
main() {
    if ! command -v nmcli >/dev/null 2>&1; then
        echo -e "${RED}Bhai, nmcli chahiye!${NC}"
        exit 1
    fi
    echo -e "${GREEN}Starting WiFi scanner...${NC}"
    while true; do
        scan_wifi
        sleep 10
    done
}

main