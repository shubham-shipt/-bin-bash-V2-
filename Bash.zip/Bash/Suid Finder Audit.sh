#!/bin/bash
#!/bin/bash

# suid_finder_audit.sh
# Finds SUID binaries, audits risks, shows colorful report

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/suid_audit.log"
RISKY_BINARIES=("vim" "nano" "less") # Known exploitable

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, SUID audit band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== SUID Finder & Audit ===${NC}"
    echo -e "${GREEN}Scanning for risky SUID binaries${NC}\n"
}

# Display SUID binaries
display_suid() {
    display_header
    printf "${BLUE}%-30s %-10s %-15s${NC}\n" "Binary" "Risk" "Details"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    while IFS='|' read -r binary risk details; do
        color=$([ "$risk" = "High" ] && echo "$RED" || [ "$risk" = "Medium" ] && echo "$YELLOW" || echo "$GREEN")
        printf "%-30s ${color}%-10s${NC} %-15s\n" "$binary" "$risk" "$details"
    done < /tmp/suid_report.txt
}

# Audit SUID
audit_suid() {
    touch "$LOG_FILE" /tmp/suid_report.txt
    > /tmp/suid_report.txt
    find / -perm -4000 2>/dev/null | while read -r binary; do
        [ ! -f "$binary" ] && continue
        risk="Low"
        details="Safe"
        # Check if writable
        if [ -w "$binary" ]; then
            risk="High"
            details="Writable"
        fi
        # Check if known risky
        for risky in "${RISKY_BINARIES[@]}"; do
            if [[ "$binary" =~ $risky ]]; then
                risk="High"
                details="Known Exploit"
            fi
        done
        echo "$binary|$risk|$details" >> /tmp/suid_report.txt
        echo "$(date '+%Y-%m-%d %H:%M:%S') $binary Risk: $risk ($details)" >> "$LOG_FILE"
    done
    display_suid
}

# Main
main() {
    echo -e "${GREEN}Starting SUID audit...${NC}"
    audit_suid
}

main