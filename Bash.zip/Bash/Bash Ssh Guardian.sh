#!/bin/bash
#!/bin/bash

# bash_ssh_guardian.sh
# Monitors SSH brute-force attempts, blocks IPs, shows colorful dashboard

# Check figlet
command -v figlet >/dev/null 2>&1 && HAS_FIGLET=1 || HAS_FIGLET=0

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/ssh_guardian.log"
AUTH_LOG="/var/log/auth.log"
THRESHOLD=5 # Attempts before block
BLOCKED_IPS="/tmp/ssh_blocked.txt"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, SSH guard band! Cleaning up...${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    if [ $HAS_FIGLET -eq 1 ]; then
        figlet -f slant "SSH Guardian"
    else
        echo -e "${BLUE}=== SSH Guardian ===${NC}"
    fi
    echo -e "${GREEN}Monitoring brute-force attempts${NC}\n"
}

# Display blocked IPs
display_blocked() {
    display_header
    printf "${BLUE}%-15s %-10s %-20s${NC}\n" "IP" "Attempts" "Blocked Time"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    [ -f "$BLOCKED_IPS" ] && tail -n 5 "$BLOCKED_IPS" | while IFS='|' read -r ip attempts time; do
        printf "${YELLOW}%-15s %-10s %-20s${NC}\n" "$ip" "$attempts" "$time"
    done
}

# Check logs and block
check_attempts() {
    touch "$BLOCKED_IPS"
    declare -A attempts
    tail -n 1000 "$AUTH_LOG" | grep "Failed password" | awk '{print $11}' | sort | uniq -c | while read -r count ip; do
        [ -z "$ip" ] && continue
        attempts[$ip]=$count
        if [ $count -ge $THRESHOLD ] && ! grep -q "$ip" "$BLOCKED_IPS"; then
            iptables -A INPUT -s "$ip" -j DROP 2>/dev/null
            timestamp=$(date '+%Y-%m-%d %H:%M:%S')
            echo "$ip|$count|$timestamp" >> "$BLOCKED_IPS"
            echo "$timestamp Blocked IP $ip ($count attempts)" >> "$LOG_FILE"
            echo -e "${RED}Blocked IP $ip ($count attempts)${NC}"
        fi
    done
    display_blocked
}

# Main
main() {
    if [ ! -f "$AUTH_LOG" ]; then
        echo -e "${RED}Bhai, $AUTH_LOG nahi mila!${NC}"
        exit 1
    fi
    if ! command -v iptables >/dev/null 2>&1; then
        echo -e "${RED}Bhai, iptables chahiye!${NC}"
        exit 1
    fi
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting SSH guardian...${NC}"
    while true; do
        check_attempts
        sleep 10
    done
}

main