#!/bin/bash

# log_rotator_plus.sh
# Custom log rotation with compression and aging, colorful output

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
MAX_SIZE=$((1024 * 1024)) # 1MB
MAX_AGE=30 # days
LOG_DIR="/var/log/custom"

# Function to display rotated logs
display_rotated() {
    clear
    echo -e "${BLUE}=== Log Rotator Plus ===${NC}"
    printf "${YELLOW}%-30s %-10s %-15s${NC}\n" "File" "Size" "Action"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    while IFS='|' read -r file size action; do
        printf "%-30s %-10s %-15s\n" "$file" "$size" "$action"
    done < /tmp/log_rotator.log
    rm -f /tmp/log_rotator.log
}

# Function to rotate log
rotate_log() {
    local file=$1
    local size=$(stat -c %s "$file" 2>/dev/null || echo 0)
    local size_kb=$((size / 1024))

    if [ $size -gt $MAX_SIZE ]; then
        local timestamp=$(date +%Y%m%d_%H%M%S)
        mv "$file" "${file}.${timestamp}"
        gzip "${file}.${timestamp}"
        echo "$file|$size_kb KB|Rotated & Compressed" >> /tmp/log_rotator.log
        touch "$file"
    fi
}

# Function to clean old logs
clean_old_logs() {
    local file=$1
    local mtime=$(stat -c %Y "$file" 2>/dev/null || echo 0)
    local now=$(date +%s)
    local age_days=$(((now - mtime) / 86400))

    if [ $age_days -gt $MAX_AGE ]; then
        rm -f "$file"
        echo "$file|N/A|Deleted (Age: $age_days days)" >> /tmp/log_rotator.log
    fi
}

# Main function
main() {
    if [ ! -d "$LOG_DIR" ]; then
        echo -e "${RED}Log directory $LOG_DIR not found!${NC}"
        exit 1
    fi

    touch /tmp/log_rotator.log
    for file in "$LOG_DIR"/*.log; do
        [ -f "$file" ] || continue
        rotate_log "$file"
    done

    for file in "$LOG_DIR"/*.gz; do
        [ -f "$file" ] || continue
        clean_old_logs "$file"
    done

    if [ -s /tmp/log_rotator.log ]; then
        display_rotated
    else
        echo -e "${GREEN}No logs rotated or deleted.${NC}"
    fi
}

# Run main
main