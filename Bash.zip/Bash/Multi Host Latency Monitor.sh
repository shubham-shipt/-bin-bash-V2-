#!/bin/bash

# multi_host_latency_monitor.sh
# Pings multiple hosts, shows latency & packet loss in colorful table

# Check for figlet
command -v figlet >/dev/null 2>&1 && HAS_FIGLET=1 || HAS_FIGLET=0

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Log file
LOG_FILE="/tmp/latency_monitor.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, ruk gaya! Cleaning up...${NC}"
    killall ping 2>/dev/null
    exit 0
}

# Fancy header
display_header() {
    clear
    if [ $HAS_FIGLET -eq 1 ]; then
        figlet -f slant "Latency Monitor"
    else
        echo -e "${BLUE}=== Latency Monitor ===${NC}"
    fi
    echo -e "${GREEN}Checking hosts in real-time${NC}\n"
}

# Display table
display_table() {
    local hosts=("$@")
    display_header
    printf "${BLUE}%-20s %-10s %-10s %-10s${NC}\n" "Host" "RTT (ms)" "Loss%" "Status"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    for host in "${hosts[@]}"; do
        if [ -f "/tmp/ping_$host" ]; then
            rtt=$(tail -n 1 "/tmp/ping_$host" | awk '{print $1}')
            loss=$(tail -n 1 "/tmp/ping_$host" | awk '{print $2}')
            if [ -z "$rtt" ] || [ "$loss" = "100" ]; then
                status="${RED}Down${NC}"
                rtt="N/A"
                loss="100"
            else
                status="${GREEN}Up${NC}"
            fi
        else
            rtt="N/A"
            loss="N/A"
            status="${RED}Error${NC}"
        fi
        printf "%-20s %-10s %-10s %-10s\n" "$host" "$rtt" "$loss" "$status"
    done
}

# Ping host and log
ping_host() {
    local host=$1
    ping -c 4 -i 0.2 "$host" | while read -r line; do
        if echo "$line" | grep -q "time="; then
            rtt=$(echo "$line" | grep -o "time=[0-9.]*" | cut -d'=' -f2)
            loss=$(ping -c 4 -i 0.2 "$host" | grep "packet loss" | awk '{print $6}' | tr -d '%')
            echo "$rtt $loss" > "/tmp/ping_$host"
            echo "$(date '+%Y-%m-%d %H:%M:%S') $host RTT: $rtt ms Loss: $loss%" >> "$LOG_FILE"
        fi
    done &
}

# Main
main() {
    if [ $# -eq 0 ]; then
        echo -e "${RED}Bhai, hosts to de! Usage: $0 <host1> <host2> ...${NC}"
        echo -e "${YELLOW}Example: $0 google.com github.com${NC}"
        exit 1
    fi

    hosts=("$@")
    touch "$LOG_FILE"

    while true; do
        for host in "${hosts[@]}"; do
            ping_host "$host"
        done
        display_table "${hosts[@]}"
        sleep 5
    done
}

main "$@"