#!/bin/bash
#!/bin/bash

# ai_command_predictor.sh
# Suggests commands from bash history with colorful table

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
HISTORY_FILE="$HOME/.bash_history"
LOG_FILE="/tmp/command_predictor.log"
TOP_N=5

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, predictor band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== AI Command Predictor ===${NC}"
    echo -e "${GREEN}Top $TOP_N command suggestions${NC}\n"
}

# Display suggestions
display_suggestions() {
    display_header
    printf "${BLUE}%-40s %-10s %-10s${NC}\n" "Command" "Frequency" "Score"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    head -n $TOP_N /tmp/predictions.txt | while IFS='|' read -r cmd freq score; do
        printf "${YELLOW}%-40s %-10s %-10s${NC}\n" "$cmd" "$freq" "$score"
    done
}

# Analyze history
analyze_history() {
    touch "$LOG_FILE" /tmp/predictions.txt
    > /tmp/predictions.txt
    # Score: frequency * (1 / (line_number / total_lines + 1)) for recency
    total_lines=$(wc -l < "$HISTORY_FILE")
    cat -n "$HISTORY_FILE" | sort -k2 | uniq -f1 -c | while read -r freq line cmd; do
        [ -z "$cmd" ] && continue
        line_num=$(echo "$line" | awk '{print $1}')
        recency=$(bc -l <<< "1 / ($line_num / $total_lines + 1)")
        score=$(bc -l <<< "$freq * $recency")
        echo "$cmd|$freq|$score" >> /tmp/predictions.txt
    done
    sort -t'|' -k3 -nr /tmp/predictions.txt -o /tmp/predictions.txt
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$timestamp Generated $TOP_N suggestions" >> "$LOG_FILE"
    display_suggestions
}

# Main
main() {
    if [ ! -f "$HISTORY_FILE" ]; then
        echo -e "${RED}Bhai, $HISTORY_FILE nahi mila!${NC}"
        exit 1
    fi
    echo -e "${GREEN}Analyzing command history...${NC}"
    analyze_history
}

main