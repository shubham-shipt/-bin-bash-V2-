#!/bin/bash

# dns_failover_checker.sh
# Monitors DNS and switches to fallback with colorful output

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
PRIMARY_DNS="8.8.8.8"
FALLBACK_DNS="1.1.1.1"
TEST_DOMAIN="google.com"
LOG_FILE="/tmp/dns_checker.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, DNS check band! Cleaning up...${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== DNS Failover Checker ===${NC}"
    echo -e "${GREEN}Monitoring DNS servers${NC}\n"
}

# Display DNS status
display_status() {
    display_header
    printf "${BLUE}%-15s %-10s %-20s${NC}\n" "DNS Server" "Status" "Last Check"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    current_dns=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}' | head -n 1)
    status=$(grep "$current_dns" "$LOG_FILE" | tail -n 1 | awk -F'|' '{print $2}' || echo "Unknown")
    timestamp=$(grep "$current_dns" "$LOG_FILE" | tail -n 1 | awk -F'|' '{print $3}' || echo "N/A")
    printf "%-15s %-10s %-20s\n" "$current_dns" "$status" "$timestamp"
}

# Check DNS
check_dns() {
    local dns=$1
    if dig @"$dns" "$TEST_DOMAIN" >/dev/null 2>&1; then
        echo "Up"
    else
        echo "Down"
    fi
}

# Switch DNS
switch_dns() {
    local new_dns=$1
    echo "nameserver $new_dns" > /etc/resolv.conf
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$new_dns|Switched|$timestamp" >> "$LOG_FILE"
    echo -e "${YELLOW}Switched to DNS $new_dns${NC}"
}

# Main
main() {
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting DNS checker...${NC}"
    while true; do
        primary_status=$(check_dns "$PRIMARY_DNS")
        if [ "$primary_status" = "Up" ]; then
            current=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}' | head -n 1)
            if [ "$current" != "$PRIMARY_DNS" ]; then
                switch_dns "$PRIMARY_DNS"
            fi
        else
            switch_dns "$FALLBACK_DNS"
        fi
        display_status
        sleep 30
    done
}

main