#!/bin/bash
#!/bin/bash

# log_pattern_intel_extractor.sh
# Extracts log patterns with colorful summary

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/pattern_extractor.log"
TOP_N=5

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, pattern extractor band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Log Pattern Extractor ===${NC}"
    echo -e "${GREEN}Analyzing $INPUT_LOG${NC}\n"
}

# Display patterns
display_patterns() {
    display_header
    printf "${BLUE}%-30s %-10s %-20s${NC}\n" "Pattern" "Count" "Type"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    head -n $TOP_N /tmp/patterns.txt | while IFS='|' read -r pattern count type; do
        printf "${YELLOW}%-30s %-10s %-20s${NC}\n" "$pattern" "$count" "$type"
    done
}

# Extract patterns
extract_patterns() {
    local log=$1
    touch "$LOG_FILE" /tmp/patterns.txt
    > /tmp/patterns.txt
    # IPs
    grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' "$log" | sort | uniq -c | while read -r count ip; do
        echo "$ip|$count|IP" >> /tmp/patterns.txt
    done
    # Errors
    grep -i "error" "$log" | awk '{print $0}' | sort | uniq -c | while read -r count err; do
        echo "${err:0:27}...|$count|Error" >> /tmp/patterns.txt
    done
    sort -t'|' -k2 -nr /tmp/patterns.txt -o /tmp/patterns.txt
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$timestamp Extracted patterns from $log" >> "$LOG_FILE"
    display_patterns
}

# Main
main() {
    if [ $# -ne 1 ]; then
        echo -e "${RED}Bhai, log file de! Usage: $0 <log_file>${NC}"
        echo -e "${YELLOW}Example: $0 /var/log/syslog${NC}"
        exit 1
    fi
    INPUT_LOG=$1
    if [ ! -f "$INPUT_LOG" ]; then
        echo -e "${RED}Log file nahi hai!${NC}"
        exit 1
    fi
    echo -e "${GREEN}Extracting patterns...${NC}"
    extract_patterns "$INPUT_LOG"
}

main "$@"