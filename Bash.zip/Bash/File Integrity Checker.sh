#!/bin/bash
#!/bin/bash

# file_integrity_checker.sh
# Checks file integrity with SHA256, shows colorful report

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
HASH_FILE="/tmp/file_hashes.txt"
LOG_FILE="/tmp/integrity.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, integrity check band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== File Integrity Checker ===${NC}"
    echo -e "${GREEN}Monitoring file changes${NC}\n"
}

# Display file status
display_status() {
    display_header
    printf "${BLUE}%-30s %-10s %-20s${NC}\n" "File" "Status" "Last Checked"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    while IFS='|' read -r file status time; do
        color=$([ "$status" = "OK" ] && echo "$GREEN" || echo "$RED")
        printf "%-30s ${color}%-10s${NC} %-20s\n" "$file" "$status" "$time"
    done < /tmp/integrity_status.txt
}

# Check integrity
check_integrity() {
    local files=("$@")
    touch "$HASH_FILE" "$LOG_FILE" /tmp/integrity_status.txt
    > /tmp/integrity_status.txt
    for file in "${files[@]}"; do
        if [ ! -f "$file" ]; then
            echo "$file|Missing|$(date '+%Y-%m-%d %H:%M:%S')" >> /tmp/integrity_status.txt
            continue
        fi
        current_hash=$(sha256sum "$file" | awk '{print $1}')
        old_hash=$(grep "$file" "$HASH_FILE" | awk '{print $1}')
        timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        if [ -z "$old_hash" ]; then
            echo "$current_hash $file" >> "$HASH_FILE"
            echo "$file|New|$timestamp" >> /tmp/integrity_status.txt
        elif [ "$current_hash" = "$old_hash" ]; then
            echo "$file|OK|$timestamp" >> /tmp/integrity_status.txt
        else
            echo "$file|Changed|$timestamp" >> /tmp/integrity_status.txt
            echo "$timestamp File $file changed!" >> "$LOG_FILE"
            sed -i "s/.*$file/$current_hash $file/" "$HASH_FILE"
        fi
    done
    display_status
}

# Main
main() {
    if [ $# -eq 0 ]; then
        echo -e "${RED}Bhai, files to de! Usage: $0 <file1> <file2> ...${NC}"
        echo -e "${YELLOW}Example: $0 /etc/passwd /etc/shadow${NC}"
        exit 1
    fi
    echo -e "${GREEN}Starting integrity checker...${NC}"
    while true; do
        check_integrity "$@"
        sleep 10
    done
}

main "$@"