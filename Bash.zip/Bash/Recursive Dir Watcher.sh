#!/bin/bash
#!/bin/bash

# recursive_dir_watcher.sh
# Watches directories recursively, shows colorful change table

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/dir_watcher.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, dir watcher band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Directory Watcher ===${NC}"
    echo -e "${GREEN}Monitoring $DIR for changes${NC}\n"
}

# Display changes
display_changes() {
    display_header
    printf "${BLUE}%-30s %-15s %-20s${NC}\n" "File" "Event" "Timestamp"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    tail -n 5 "$LOG_FILE" | while IFS='|' read -r file event time; do
        printf "${YELLOW}%-30s %-15s %-20s${NC}\n" "$file" "$event" "$time"
    done
}

# Watch directory
watch_dir() {
    local dir=$1
    inotifywait -m "$dir" -r -e create -e modify -e delete | while read -r path action file; do
        timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        echo "$path$file|$action|$timestamp" >> "$LOG_FILE"
        display_changes
    done &
}

# Main
main() {
    if [ $# -ne 1 ]; then
        echo -e "${RED}Bhai, directory de! Usage: $0 <dir>${NC}"
        echo -e "${YELLOW}Example: $0 /var/log${NC}"
        exit 1
    fi
    DIR=$1
    if [ ! -d "$DIR" ]; then
        echo -e "${RED}Directory nahi hai!${NC}"
        exit 1
    fi
    if ! command -v inotifywait >/dev/null 2>&1; then
        echo -e "${RED}inotify-tools chahiye!${NC}"
        exit 1
    fi
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting dir watcher for $DIR...${NC}"
    watch_dir "$DIR"
    wait
}

main "$@"