#!/bin/bash

# parallel_process_manager.sh
# Advanced script to run and monitor parallel processes with colorful GUI output

# Check for figlet
command -v figlet >/dev/null 2>&1 && HAS_FIGLET=1 || HAS_FIGLET=0

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Trap Ctrl+C for cleanup
trap cleanup SIGINT

# Array to store PIDs and commands
declare -A PIDS
declare -A COMMANDS
declare -A STATUSES

# Cleanup function
cleanup() {
    echo -e "\n${RED}Caught interrupt! Cleaning up...${NC}"
    for pid in "${!PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null
            wait "$pid" 2>/dev/null
            echo -e "${YELLOW}Terminated PID $pid (${COMMANDS[$pid]})${NC}"
        fi
    done
    exit 1
}

# Function to display fancy header
display_header() {
    clear
    if [ $HAS_FIGLET -eq 1 ]; then
        figlet -f slant "Parallel Manager"
    else
        echo -e "${BLUE}=== Parallel Process Manager ===${NC}"
    fi
    echo -e "${GREEN}Monitoring processes in real-time${NC}\n"
}

# Function to display process table
display_table() {
    display_header
    printf "${BLUE}%-10s %-30s %-10s %-10s %-10s${NC}\n" "PID" "Command" "Status" "CPU%" "Mem%"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------------------"
    for pid in "${!PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            status="${GREEN}Running${NC}"
            # Get CPU and memory usage
            cpu=$(ps -p "$pid" -o %cpu | tail -n 1 | awk '{print $1}')
            mem=$(ps -p "$pid" -o %mem | tail -n 1 | awk '{print $1}')
        else
            status="${RED}${STATUSES[$pid]:-Failed}${NC}"
            cpu="0.0"
            mem="0.0"
        fi
        printf "%-10s %-30s %-10s %-10s %-10s\n" "$pid" "${COMMANDS[$pid]:0:27}..." "$status" "$cpu" "$mem"
    done
}

# Function to start a process
start_process() {
    local cmd="$1"
    bash -c "$cmd" &
    pid=$!
    PIDS[$pid]=$pid
    COMMANDS[$pid]="$cmd"
    STATUSES[$pid]="Running"
}

# Main function
main() {
    if [ $# -eq 0 ]; then
        echo -e "${RED}Usage: $0 <command1> <command2> ...${NC}"
        echo -e "${YELLOW}Example: $0 'sleep 10' 'echo Hello' 'ls -l'${NC}"
        exit 1
    fi

    # Start all processes
    for cmd in "$@"; do
        start_process "$cmd"
    done

    # Monitor processes
    while [ ${#PIDS[@]} -gt 0 ]; do
        for pid in "${!PIDS[@]}"; do
            if ! kill -0 "$pid" 2>/dev/null; then
                wait "$pid" 2>/dev/null
                if [ $? -eq 0 ]; then
                    STATUSES[$pid]="Completed"
                else
                    STATUSES[$pid]="Failed"
                fi
                unset PIDS[$pid]
            fi
        done
        display_table
        sleep 1
    done

    # Final display
    display_table
    echo -e "\n${GREEN}All processes completed!${NC}"
}

# Run main
main "$@"