#!/bin/bash

# net_interface_auto_repair.sh
# Detects and fixes downed interfaces with colorful dashboard

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Log file
LOG_FILE="/tmp/interface_repair.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, repair band! Cleaning up...${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Interface Auto Repair ===${NC}"
    echo -e "${GREEN}Monitoring network interfaces${NC}\n"
}

# Display interfaces
display_interfaces() {
    display_header
    printf "${BLUE}%-10s %-10s %-20s${NC}\n" "Interface" "Status" "Last Action"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    ip link | awk -F': ' '/^[0-9]+:/ {print $2}' | while read -r iface; do
        status=$(ip link show "$iface" | grep -q "UP" && echo "${GREEN}Up${NC}" || echo "${RED}Down${NC}")
        last_action=$(grep "$iface" "$LOG_FILE" | tail -n 1 | awk -F'|' '{print $2}' || echo "None")
        printf "%-10s %-10s %-20s\n" "$iface" "$status" "$last_action"
    done
}

# Check and repair
check_repair() {
    ip link | awk -F': ' '/^[0-9]+:/ {print $2}' | while read -r iface; do
        if ! ip link show "$iface" | grep -q "UP"; then
            echo -e "${YELLOW}Repairing $iface...${NC}"
            ifdown "$iface" 2>/dev/null
            ifup "$iface" 2>/dev/null
            timestamp=$(date '+%Y-%m-%d %H:%M:%S')
            echo "$iface|Repaired|$timestamp" >> "$LOG_FILE"
        fi
    done
}

# Main
main() {
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting interface repair...${NC}"
    while true; do
        check_repair
        display_interfaces
        sleep 10
    done
}

main