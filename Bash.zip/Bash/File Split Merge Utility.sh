#!/bin/bash
#!/bin/bash

# file_split_merge_utility.sh
# Splits/merges files with colorful progress report

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/split_merge.log"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, split/merge band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== File Split/Merge Utility ===${NC}"
    echo -e "${GREEN}Processing files${NC}\n"
}

# Display status
display_status() {
    display_header
    printf "${BLUE}%-30s %-10s %-20s${NC}\n" "File" "Status" "Timestamp"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    tail -n 5 "$LOG_FILE" | while IFS='|' read -r file status time; do
        color=$([ "$status" = "OK" ] && echo "$GREEN" || echo "$RED")
        printf "%-30s ${color}%-10s${NC} %-20s\n" "$file" "$status" "$time"
    done
}

# Split file
split_file() {
    local file=$1
    local size=$2
    local prefix=$(basename "$file")_part
    split -b "$size" "$file" "$prefix" 2>/dev/null
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$file|Split|$timestamp" >> "$LOG_FILE"
    display_status
}

# Merge files
merge_files() {
    local prefix=$1
    local output=$2
    cat "$prefix"* > "$output" 2>/dev/null
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    orig_hash=$(sha256sum "$output" | awk '{print $1}')
    echo "$output|Merged|$timestamp" >> "$LOG_FILE"
    display_status
}

# Main
main() {
    if [ $# -lt 2 ]; then
        echo -e "${RED}Bhai, command de! Usage: $0 {split|merge} <args>${NC}"
        echo -e "${YELLOW}Example: $0 split large.txt 1M${NC}"
        exit 1
    fi
    action=$1
    shift
    touch "$LOG_FILE"
    case "$action" in
        split)
            if [ $# -ne 2 ]; then
                echo -e "${RED}File aur size de!${NC}"
                exit 1
            fi
            file=$1
            size=$2
            if [ ! -f "$file" ]; then
                echo -e "${RED}File nahi hai!${NC}"
                exit 1
            fi
            echo -e "${GREEN}Splitting $file...${NC}"
            split_file "$file" "$size"
            ;;
        merge)
            if [ $# -ne 2 ]; then
                echo -e "${RED}Prefix aur output de!${NC}"
                exit 1
            fi
            prefix=$1
            output=$2
            echo -e "${GREEN}Merging $prefix to $output...${NC}"
            merge_files "$prefix" "$output"
            ;;
        *)
            echo -e "${RED}Galat action! Use split, merge${NC}"
            exit 1
            ;;
    esac
}

main "$@"