#!/bin/bash
#!/bin/bash

# smart_backup_engine.sh
# Full/incremental backups with checksums, colorful status

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
BACKUP_DIR="/backup"
SOURCE_DIR=""
LOG_FILE="/tmp/backup.log"
CHECKSUM_FILE="/tmp/backup_checksums.txt"

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, backup band!${NC}"
    exit 0
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Smart Backup Engine ===${NC}"
    echo -e "${GREEN}Backing up $SOURCE_DIR${NC}\n"
}

# Display backup status
display_status() {
    display_header
    printf "${BLUE}%-30s %-10s %-20s${NC}\n" "File" "Status" "Timestamp"
    printf "${BLUE}%s${NC}\n" "-------------------------------------------------"
    tail -n 5 "$LOG_FILE" | while IFS='|' read -r file status time; do
        color=$([ "$status" = "OK" ] && echo "$GREEN" || echo "$RED")
        printf "%-30s ${color}%-10s${NC} %-20s\n" "$file" "$status" "$time"
    done
}

# Verify checksum
verify_checksum() {
    local file=$1
    local backup_file="$BACKUP_DIR/$file"
    if [ -f "$backup_file" ]; then
        src_hash=$(sha256sum "$file" | awk '{print $1}')
        backup_hash=$(sha256sum "$backup_file" | awk '{print $1}')
        [ "$src_hash" = "$backup_hash" ] && return 0 || return 1
    fi
    return 1
}

# Perform backup
do_backup() {
    local type=$1
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    mkdir -p "$BACKUP_DIR"
    if [ "$type" = "full" ]; then
        rsync -a "$SOURCE_DIR/" "$BACKUP_DIR/" >> "$LOG_FILE" 2>&1
    else
        rsync -a --link-dest="$BACKUP_DIR" "$SOURCE_DIR/" "$BACKUP_DIR/" >> "$LOG_FILE" 2>&1
    fi
    for file in $(find "$SOURCE_DIR" -type f); do
        rel_file=${file#$SOURCE_DIR/}
        if verify_checksum "$file"; then
            echo "$rel_file|OK|$timestamp" >> "$LOG_FILE"
        else
            echo "$rel_file|Failed|$timestamp" >> "$LOG_FILE"
        fi
    done
    display_status
}

# Main
main() {
    if [ $# -ne 2 ]; then
        echo -e "${RED}Bhai, type aur dir de! Usage: $0 {full|incremental} <source_dir>${NC}"
        echo -e "${YELLOW}Example: $0 full /home/user${NC}"
        exit 1
    fi
    type=$1
    SOURCE_DIR=$2
    if [ ! -d "$SOURCE_DIR" ]; then
        echo -e "${RED}Source dir nahi hai!${NC}"
        exit 1
    fi
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting $type backup...${NC}"
    do_backup "$type"
}

main "$@"