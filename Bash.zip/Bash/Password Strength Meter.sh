#!/bin/bash
#!/bin/bash

# password_strength_meter.sh
# Analyzes password strength with colorful meter

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Draw progress bar
draw_bar() {
    local value=$1
    local width=20
    local filled=$((value * width / 100))
    local empty=$((width - filled))
    printf "${GREEN}"
    printf "%${filled}s" | tr ' ' '█'
    printf "${NC}"
    printf "%${empty}s" | tr ' ' ' '
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== Password Strength Meter ===${NC}"
    echo -e "${GREEN}Analyzing your password${NC}\n"
}

# Analyze password
analyze_password() {
    local pass=$1
    local score=0
    local length=${#pass}

    # Length check
    [ $length -ge 8 ] && score=$((score + 20))
    [ $length -ge 12 ] && score=$((score + 20))

    # Character types
    echo "$pass" | grep -q "[A-Z]" && score=$((score + 15))
    echo "$pass" | grep -q "[a-z]" && score=$((score + 15))
    echo "$pass" | grep -q "[0-9]" && score=$((score + 15))
    echo "$pass" | grep -q "[^A-Za-z0-9]" && score=$((score + 15))

    # Rank
    if [ $score -ge 80 ]; then
        rank="${GREEN}Strong${NC}"
    elif [ $score -ge 50 ]; then
        rank="${YELLOW}Moderate${NC}"
    else
        rank="${RED}Weak${NC}"
    fi

    # Display
    display_header
    printf "${BLUE}%-15s %-10s %-20s${NC}\n" "Score" "Rank" "Strength"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    printf "%-15s %-10s " "$score" "$rank"
    draw_bar "$score"
    printf "\n"
}

# Main
main() {
    echo -e "${YELLOW}Bhai, password daal (hidden hai): ${NC}"
    read -s pass
    if [ -z "$pass" ]; then
        echo -e "${RED}Password to daal, bhai!${NC}"
        exit 1
    fi
    analyze_password "$pass"
}

main