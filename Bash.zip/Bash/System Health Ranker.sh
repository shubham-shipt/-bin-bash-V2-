#!/bin/bash
#!/bin/bash

# system_health_ranker.sh
# Ranks system health with colorful dashboard

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Config
LOG_FILE="/tmp/health_ranker.log"
WEIGHTS=(0.4 0.3 0.3) # CPU, Mem, Disk

# Trap Ctrl+C
trap cleanup SIGINT

cleanup() {
    echo -e "\n${RED}Bhai, health ranker band!${NC}"
    exit 0
}

# Draw progress bar
draw_bar() {
    local value=$1
    local width=20
    local filled=$((value * width / 100))
    local empty=$((width - filled))
    printf "${GREEN}"
    printf "%${filled}s" | tr ' ' '█'
    printf "${NC}"
    printf "%${empty}s" | tr ' ' ' '
}

# Fancy header
display_header() {
    clear
    echo -e "${BLUE}=== System Health Ranker ===${NC}"
    echo -e "${GREEN}Monitoring system health${NC}\n"
}

# Display health
display_health() {
    local cpu=$1 mem=$2 disk=$3 score=$4
    display_header
    printf "${BLUE}%-10s %-10s %-20s${NC}\n" "Metric" "Usage%" "Status"
    printf "${BLUE}%s${NC}\n" "---------------------------------------------"
    printf "%-10s %-10s " "CPU" "$cpu"
    draw_bar "$cpu"
    printf "\n"
    printf "%-10s %-10s " "Memory" "$mem"
    draw_bar "$mem"
    printf "\n"
    printf "%-10s %-10s " "Disk" "$disk"
    draw_bar "$disk"
    printf "\n"
    printf "${YELLOW}Health Score: %.2f${NC}\n" "$score"
}

# Check health
check_health() {
    # CPU usage (100 - idle)
    cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}')
    # Memory usage
    mem=$(free | grep Mem | awk '{print ($3/$2)*100}')
    # Disk usage
    disk=$(df / | tail -n 1 | awk '{print $5}' | tr -d '%')
    # Weighted score (lower is better)
    score=$(bc -l <<< "${WEIGHTS[0]}*$cpu + ${WEIGHTS[1]}*$mem + ${WEIGHTS[2]}*$disk")
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$timestamp CPU:$cpu% Mem:$mem% Disk:$disk% Score:$score" >> "$LOG_FILE"
    display_health "$cpu" "$mem" "$disk" "$score"
}

# Main
main() {
    touch "$LOG_FILE"
    echo -e "${GREEN}Starting health ranker...${NC}"
    while true; do
        check_health
        sleep 5
    done
}

main